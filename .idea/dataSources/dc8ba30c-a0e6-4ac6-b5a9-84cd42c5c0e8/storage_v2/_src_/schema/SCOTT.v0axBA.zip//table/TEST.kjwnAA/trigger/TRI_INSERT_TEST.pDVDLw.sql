create trigger TRI_INSERT_TEST
  before insert
  on TEST
  for each row
begin
select seq_test.nextval
into:new.id
from dual;
end;
/

