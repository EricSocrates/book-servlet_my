create trigger DEPT_LOG
  before insert or update or delete
  on DEPT
declare val varchar2(20);
begin
if inserting then
val := '有新的能量产生';
elsif updating then
val := '有人偷能量了！';
elsif deleting then
val := '能量已收集完毕';
end if;
insert into dept_log values(val, sysdate);
end;
/

