create view V_ENAME_DNAME as
select emp.ename empname, dept.dname deptname from emp
left join dept on emp.deptno = dept.deptno
/

