create procedure
pro_hi(dzh in number, bb out varchar)
as
begin
if dzh = 1
then bb := '你好';
else if dzh = 2
then bb := '再见';
end if;
end if;
end;
/

